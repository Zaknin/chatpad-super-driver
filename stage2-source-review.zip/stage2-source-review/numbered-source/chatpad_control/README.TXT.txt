     1	Hi, this is the README.TXT file for the Chatpad Super Driver by GAFBlizzard (AKA Blizzard AKA AgentElrond).
     2	
     3	Please see the driver website (http://code.google.com/p/chatpad-super-driver/) for information about the driver,
     4	how to install and use it, and to get updated versions.
     5	
     6	
     7	
     8	
     9	************************************
    10	Lists of configuration file strings:
    11	************************************
    12	
    13	Here are some lists of strings that can be used in chatpad_config.txt.  See the
    14	comments in chatpad_config.txt for information on how to use these strings.
    15	These strings are not case-sensitive.
    16	
    17	
    18	Configuration settings
    19	=================================
    20	ENABLE_WINDOWS_MODE
    21	ENABLE_WINDOWS_MODE_PEOPLE_KEY_INDICATOR
    22	CAPS_LOCK_CONTROLS_SHIFT_INDICATOR
    23	ENABLE_INGAME_REMAPPED_BUTTONS
    24	THUMBSTICK_MOUSE_SENSITIVITY
    25	
    26	
    27	Chatpad keys
    28	=================================
    29	CHATPAD_KEY_1
    30	CHATPAD_KEY_2
    31	CHATPAD_KEY_3
    32	CHATPAD_KEY_4
    33	CHATPAD_KEY_5
    34	CHATPAD_KEY_6
    35	CHATPAD_KEY_7
    36	CHATPAD_KEY_8
    37	CHATPAD_KEY_9
    38	CHATPAD_KEY_0
    39	CHATPAD_KEY_Q
    40	CHATPAD_KEY_W
    41	CHATPAD_KEY_E
    42	CHATPAD_KEY_R
    43	CHATPAD_KEY_T
    44	CHATPAD_KEY_Y
    45	CHATPAD_KEY_U
    46	CHATPAD_KEY_I
    47	CHATPAD_KEY_O
    48	CHATPAD_KEY_P
    49	CHATPAD_KEY_A
    50	CHATPAD_KEY_S
    51	CHATPAD_KEY_D
    52	CHATPAD_KEY_F
    53	CHATPAD_KEY_G
    54	CHATPAD_KEY_H
    55	CHATPAD_KEY_J
    56	CHATPAD_KEY_K
    57	CHATPAD_KEY_L
    58	CHATPAD_KEY_COMMA
    59	CHATPAD_KEY_SHIFT
    60	CHATPAD_KEY_Z
    61	CHATPAD_KEY_X
    62	CHATPAD_KEY_C
    63	CHATPAD_KEY_V
    64	CHATPAD_KEY_B
    65	CHATPAD_KEY_N
    66	CHATPAD_KEY_M
    67	CHATPAD_KEY_PERIOD
    68	CHATPAD_KEY_ENTER
    69	CHATPAD_KEY_GREEN             (this is the green square button on the bottom left of the chatpad)
    70	CHATPAD_KEY_PEOPLE            (this is the button to the left of the left arrow on the chatpad)
    71	CHATPAD_KEY_LEFT
    72	CHATPAD_KEY_SPACEBAR
    73	CHATPAD_KEY_RIGHT
    74	CHATPAD_KEY_BACKSPACE
    75	CHATPAD_KEY_ORANGE            (this is the orange circle button on the bottom right of the chatpad)
    76	
    77	
    78	Chatpad key modifiers
    79	=================================
    80	CHATPAD_SHIFT
    81	CHATPAD_GREEN
    82	CHATPAD_ORANGE
    83	CHATPAD_PEOPLE
    84	
    85	
    86	Controller buttons
    87	=================================
    88	CONTROLLER_BUTTON_LB
    89	CONTROLLER_BUTTON_RB
    90	CONTROLLER_BUTTON_BACK
    91	CONTROLLER_BUTTON_GUIDE
    92	CONTROLLER_BUTTON_START
    93	CONTROLLER_BUTTON_LEFT_STICK_CLICK
    94	CONTROLLER_BUTTON_RIGHT_STICK_CLICK
    95	CONTROLLER_BUTTON_A
    96	CONTROLLER_BUTTON_B
    97	CONTROLLER_BUTTON_X
    98	CONTROLLER_BUTTON_Y
    99	
   100	
   101	Controller key modifiers
   102	=================================
   103	CONTROLLER_WINDOWS_MODE       (When Windows Mode is active, controller thumbsticks control the mouse,
   104	                               and the 360 controller's buttons are disabled or may have alternate bindings.
   105	                               The controller's buttons cannot be used as normal buttons in Windows Mode.)
   106	
   107	
   108	Simulated keyboard keys
   109	=================================
   110	   (Note that to map to shift, alt, ctrl, and Windows keys, you will need to use special actions instead)
   111	KEYBOARD_KEY_A
   112	KEYBOARD_KEY_B
   113	KEYBOARD_KEY_C
   114	KEYBOARD_KEY_D
   115	KEYBOARD_KEY_E
   116	KEYBOARD_KEY_F
   117	KEYBOARD_KEY_G
   118	KEYBOARD_KEY_H
   119	KEYBOARD_KEY_I
   120	KEYBOARD_KEY_J
   121	KEYBOARD_KEY_K
   122	KEYBOARD_KEY_L
   123	KEYBOARD_KEY_M
   124	KEYBOARD_KEY_N
   125	KEYBOARD_KEY_O
   126	KEYBOARD_KEY_P
   127	KEYBOARD_KEY_Q
   128	KEYBOARD_KEY_R
   129	KEYBOARD_KEY_S
   130	KEYBOARD_KEY_T
   131	KEYBOARD_KEY_U
   132	KEYBOARD_KEY_V
   133	KEYBOARD_KEY_W
   134	KEYBOARD_KEY_X
   135	KEYBOARD_KEY_Y
   136	KEYBOARD_KEY_Z
   137	KEYBOARD_KEY_1
   138	KEYBOARD_KEY_2
   139	KEYBOARD_KEY_3
   140	KEYBOARD_KEY_4
   141	KEYBOARD_KEY_5
   142	KEYBOARD_KEY_6
   143	KEYBOARD_KEY_7
   144	KEYBOARD_KEY_8
   145	KEYBOARD_KEY_9
   146	KEYBOARD_KEY_0
   147	KEYBOARD_KEY_ENTER
   148	KEYBOARD_KEY_ESCAPE
   149	KEYBOARD_KEY_BACKSPACE
   150	KEYBOARD_KEY_TAB
   151	KEYBOARD_KEY_SPACEBAR
   152	KEYBOARD_KEY_MINUS
   153	KEYBOARD_KEY_EQUALS
   154	KEYBOARD_KEY_OPEN_BRACKET
   155	KEYBOARD_KEY_CLOSE_BRACKET
   156	KEYBOARD_KEY_BACKSLASH
   157	KEYBOARD_KEY_SEMICOLON
   158	KEYBOARD_KEY_APOSTROPHE
   159	KEYBOARD_KEY_GRAVE_ACCENT     (left single quote near '1' on a keyboard)
   160	KEYBOARD_KEY_COMMA
   161	KEYBOARD_KEY_PERIOD
   162	KEYBOARD_KEY_FORWARDSLASH
   163	KEYBOARD_KEY_CAPS_LOCK
   164	KEYBOARD_KEY_F1
   165	KEYBOARD_KEY_F2
   166	KEYBOARD_KEY_F3
   167	KEYBOARD_KEY_F4
   168	KEYBOARD_KEY_F5
   169	KEYBOARD_KEY_F6
   170	KEYBOARD_KEY_F7
   171	KEYBOARD_KEY_F8
   172	KEYBOARD_KEY_F9
   173	KEYBOARD_KEY_F10
   174	KEYBOARD_KEY_F11
   175	KEYBOARD_KEY_F12
   176	KEYBOARD_KEY_PRINTSCREEN
   177	KEYBOARD_KEY_SCROLL_LOCK
   178	KEYBOARD_KEY_PAUSE
   179	KEYBOARD_KEY_INSERT
   180	KEYBOARD_KEY_HOME
   181	KEYBOARD_KEY_PAGEUP
   182	KEYBOARD_KEY_DELETE
   183	KEYBOARD_KEY_END
   184	KEYBOARD_KEY_PAGEDOWN
   185	KEYBOARD_KEY_RIGHT
   186	KEYBOARD_KEY_LEFT
   187	KEYBOARD_KEY_DOWN
   188	KEYBOARD_KEY_UP
   189	KEYBOARD_KEY_KEYPAD_NUM_LOCK
   190	KEYBOARD_KEY_KEYPAD_FORWARDSLASH
   191	KEYBOARD_KEY_KEYPAD_ASTERISK
   192	KEYBOARD_KEY_KEYPAD_MINUS
   193	KEYBOARD_KEY_KEYPAD_PLUS
   194	KEYBOARD_KEY_KEYPAD_ENTER
   195	KEYBOARD_KEY_KEYPAD_1
   196	KEYBOARD_KEY_KEYPAD_2
   197	KEYBOARD_KEY_KEYPAD_3
   198	KEYBOARD_KEY_KEYPAD_4
   199	KEYBOARD_KEY_KEYPAD_5
   200	KEYBOARD_KEY_KEYPAD_6
   201	KEYBOARD_KEY_KEYPAD_7
   202	KEYBOARD_KEY_KEYPAD_8
   203	KEYBOARD_KEY_KEYPAD_9
   204	KEYBOARD_KEY_KEYPAD_0
   205	KEYBOARD_KEY_KEYPAD_PERIOD
   206	KEYBOARD_KEY_F13
   207	KEYBOARD_KEY_F14
   208	KEYBOARD_KEY_F15
   209	KEYBOARD_KEY_F16
   210	KEYBOARD_KEY_F17
   211	KEYBOARD_KEY_F18
   212	KEYBOARD_KEY_F19
   213	KEYBOARD_KEY_F20
   214	KEYBOARD_KEY_F21
   215	KEYBOARD_KEY_F22
   216	KEYBOARD_KEY_F23
   217	KEYBOARD_KEY_F24
   218	KEYBOARD_KEY_EXECUTE
   219	KEYBOARD_KEY_HELP
   220	KEYBOARD_KEY_MENU
   221	KEYBOARD_KEY_SELECT
   222	KEYBOARD_KEY_STOP
   223	KEYBOARD_KEY_AGAIN
   224	KEYBOARD_KEY_UNDO
   225	KEYBOARD_KEY_CUT
   226	KEYBOARD_KEY_COPY
   227	KEYBOARD_KEY_PASTE
   228	KEYBOARD_KEY_FIND
   229	   (Note that the following three key bindings do not work on my machine, but you can try them if you want -- GAFBlizzard)
   230	KEYBOARD_KEY_MUTE
   231	KEYBOARD_KEY_VOLUME_UP
   232	KEYBOARD_KEY_VOLUME_DOWN
   233	
   234	
   235	Keyboard key modifiers
   236	=================================
   237	KEYBOARD_LEFT_CONTROL
   238	KEYBOARD_LEFT_SHIFT
   239	KEYBOARD_LEFT_ALT
   240	   (Note that the GUI modifiers correspond to the Windows logo keys on a normal keyboard)
   241	KEYBOARD_LEFT_GUI
   242	KEYBOARD_RIGHT_CONTROL
   243	KEYBOARD_RIGHT_SHIFT
   244	KEYBOARD_RIGHT_ALT
   245	KEYBOARD_RIGHT_GUI
   246	
   247	
   248	Simulated mouse clicks
   249	=======================================
   250	MOUSE_CLICK_LEFT
   251	MOUSE_CLICK_MIDDLE
   252	MOUSE_CLICK_RIGHT
   253	MOUSE_WHEEL_UP
   254	MOUSE_WHEEL_DOWN
   255	
   256	
   257	Special actions
   258	=======================================
   259	SPECIAL_ACTION_LEFT_CTRL
   260	SPECIAL_ACTION_LEFT_CTRL_LATCH
   261	   (Note that the left shift or left shift latch should normally be used rather
   262	    than right shift, since right shift and right shift latch currently do not
   263	    act as chatpad modifiers.  They also do not use the shift key indicator light.
   264	    They may not even work properly.  Basically, ask GAFBlizzard if you need special
   265	    functionality from the right shift key.)
   266	SPECIAL_ACTION_LEFT_SHIFT
   267	SPECIAL_ACTION_LEFT_SHIFT_LATCH
   268	SPECIAL_ACTION_LEFT_ALT
   269	SPECIAL_ACTION_LEFT_ALT_LATCH
   270	   (Note that the GUI special actions correspond to the Windows logo keys on a normal keyboard)
   271	SPECIAL_ACTION_LEFT_GUI
   272	SPECIAL_ACTION_LEFT_GUI_LATCH
   273	SPECIAL_ACTION_RIGHT_CTRL
   274	SPECIAL_ACTION_RIGHT_CTRL_LATCH
   275	SPECIAL_ACTION_RIGHT_SHIFT
   276	SPECIAL_ACTION_RIGHT_SHIFT_LATCH
   277	SPECIAL_ACTION_RIGHT_ALT
   278	SPECIAL_ACTION_RIGHT_ALT_LATCH
   279	SPECIAL_ACTION_RIGHT_GUI
   280	SPECIAL_ACTION_RIGHT_GUI_LATCH
   281	SPECIAL_ACTION_ORANGE
   282	SPECIAL_ACTION_ORANGE_LATCH
   283	SPECIAL_ACTION_GREEN
   284	SPECIAL_ACTION_GREEN_LATCH
   285	SPECIAL_ACTION_PEOPLE
   286	SPECIAL_ACTION_PEOPLE_LATCH
   287	SPECIAL_ACTION_TOGGLE_WINDOWS_MODE
   288	
   289	
